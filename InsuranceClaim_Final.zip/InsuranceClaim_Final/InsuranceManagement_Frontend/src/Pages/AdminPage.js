import React from 'react'
import AdminPolicies from '../components/adminPolicies/AdminPolicies'

const AdminPage = () => {
  return (
    <div>
      <AdminPolicies />
    </div>

  )
}

export default AdminPage